package main

import (
	"archive/zip"
	"log"
	"os"
)

func main() {
	f, err := os.Open("test.zip")
	if err != nil {
		log.Fatal(`error open file: `, err)
	}

	zw := zip.NewWriter(f)
	w, err := zw.Create(`testfile`)
	if err != nil {
		log.Fatal(`error creating file writer: `, err)
	}
	_, err = w.Write([]byte(`hello world`))
	if err != nil {
		log.Fatal(`error writing file contents: `, err)
	}
	zw.Close()
}
